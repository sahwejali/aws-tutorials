This tool is from Ansible:

https://github.com/ansible/ansible/tree/devel/plugins

