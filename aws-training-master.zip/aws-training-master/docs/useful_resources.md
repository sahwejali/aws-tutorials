
- [AWS Documentation](http://aws.amazon.com/documentation/)

- [Auto Scaling](http://docs.aws.amazon.com/AutoScaling/latest/DeveloperGuide/AutoScalingGroupLifecycle.html)
- [Elastic Load Balancing](http://docs.aws.amazon.com/ElasticLoadBalancing/latest/DeveloperGuide/SvcIntro_HowELBWorks.html)

- [CloudFormation: Resource types](http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-template-resource-type-ref.html)

- [Ansible: Cloud modules](http://docs.ansible.com/list_of_cloud_modules.html)
- [Ansible: Dynamic inventory](http://docs.ansible.com/intro_dynamic_inventory.html#example-aws-ec2-external-inventory-script)
